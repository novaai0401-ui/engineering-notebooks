---
description: Full pipeline - inventory, journeys, tests, then run the selected journey
agent: api-runner
---
Run the full API automation pipeline for journey "${input:journey:journey name or all}":
1. Invoke the api-inventory procedure (fresh inventory).
2. Invoke the api-journey procedure for the journey.
3. Invoke the api-test-builder procedure.
4. Run the journey with the current config and report.
If the agent tool is available, call @api-inventory, @api-journey and @api-test-builder in that order; otherwise
perform each agent's procedure yourself, in order, before running.
