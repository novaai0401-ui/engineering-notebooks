---
description: Make this Spring Boot repo runnable and debuggable in VS Code (replaces IntelliJ setup)
agent: spring-vscode
---
Set up this Spring Boot repo for VS Code: detect JDK, build tool, main class, profiles and env vars (translate any
IntelliJ run configs), write .vscode settings/launch/tasks/extensions and api.http, install extensions, compile, run the
local profile, hit the health endpoint, run one unit test, and record everything in SETUP.md. Do not touch pom/gradle
or source files. Stop and tell me if the required JDK is missing.
