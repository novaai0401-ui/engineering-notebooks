Compatibility copies of every agent for Copilot Chat builds that reject `handoffs` or the `agent` tool.
Same behaviour, same prompts. Use these instead of the originals: copy all *.agent.md into C:\copilot-kit\agents (replace),
then Developer: Reload Window. Handoffs are replaced by the agent telling you which agent to run next.
