---
description: Fresh inventory of all exposed and consumed APIs, config, DB tables and dependency map
agent: api-inventory
---
Regenerate api/inventory.json and api/INVENTORY.md from scratch for this repo on the current branch. Include exposed
endpoints, third-party and internal APIs called, config keys (placeholders only), DB tables per endpoint, and the
dependency map. Report counts and anything unresolved.
