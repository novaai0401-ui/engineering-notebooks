---
description: Generate automated test suite, Postman collection and curl scripts from the journeys
agent: api-test-builder
---
Generate api/tests/ from api/journeys/*.journey.json: code suite for this repo's stack, Postman collection + environment,
curl scripts (bash and PowerShell), and run.ps1 / run.sh with per-journey selection. Verify in mock mode and report.
