# Spring Boot in VS Code kit (no IntelliJ needed)

One agent, `spring-vscode`, turns any Spring Boot repo (Maven or Gradle, single or multi-module) into a VS Code
project: F5 runs the app with the right profile and env vars, tests run from the Test explorer, Maven/Gradle tasks
are one click, REST calls run from `api.http` without Postman, and the setup is recorded in SETUP.md so the next
laptop is one command.

## Files
| Path | Purpose |
|------|---------|
| `.github/agents/spring-vscode.agent.md` | the agent (detect, write .vscode, install extensions, build, run, smoke test, record) |
| `.github/prompts/spring-vscode.prompt.md` | `/spring-vscode` one-time setup |
| `.github/prompts/spring-run.prompt.md` | `/spring-run` build + run + health + optional API journey |
| `.vscode/extensions.json` | Java pack, Spring Boot pack, Maven, Gradle, YAML, XML, SonarLint, Docker, REST Client, Copilot |
| `.vscode/settings.json` | JDK runtimes, Maven user settings, wrapper, formatter, test profile (template: the agent fills real paths) |
| `.vscode/launch.json` | Spring Boot local run, attach debug on 5005, test profile |
| `.vscode/tasks.json` | compile / test / test one / package / verify / run / run with debug / gradle / docker compose / api journey |
| `.vscode/api.http` | REST Client requests: health, login, business call with token chaining |
| `.env.local.example` | env var names for local runs; copy to `.env.local` |

## Use
1. Install the agent: copy `.github/agents` and `.github/prompts` into `C:\copilot-kit\agents` / `prompts` (user-level,
   same as the main kit) or into the repo's `.github/`.
2. Open the Spring Boot repo in VS Code, Copilot Chat, Agent mode, run `/spring-vscode`.
   The agent detects everything, writes `.vscode/`, installs extensions, compiles, runs the local profile, hits
   `/actuator/health`, runs one unit test, and records the result in SETUP.md. If the JDK is missing it prints the
   install command and waits.
3. Daily: press `F5` ("Spring Boot: local"), or `Ctrl+Shift+B` for build tasks, or `/spring-run local`.
   Debug a running container / remote: start "Spring Boot: debug (attach 5005)".
4. API checks: open `.vscode/api.http`, click "Send Request". For whole journeys use the API Automation Kit next to the
   repo: the task "api: run journey" calls it.

## What the agent reads from IntelliJ
`.idea/runConfigurations/*.xml` and `.run/*.run.xml` hold the profiles, VM args and env vars people set up by hand.
Each becomes a launch.json configuration, so nothing from the IntelliJ setup is lost. `.idea/` is left in place.

## Secrets
`.env.local` is git-excluded and holds local values only. With the main kit vault, run
`powershell -File C:\copilot-kit\secrets.ps1 env` in the terminal before F5 and launch.json picks them up via `${env:NAME}`.
