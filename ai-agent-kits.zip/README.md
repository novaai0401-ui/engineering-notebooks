# AI Agent Kits (all-in-one)

| Folder | What | Start here |
|--------|------|------------|
| `copilot-agents-kit/` | Core: Copilot agents (context-builder, setup, product, feature-loop, ui-dev, api-dev, java-dev, devops, reviewer, planner), Devin playbooks + knowledge, shared context, secrets vault | `copilot-agents-kit/FINAL-SETUP.md` |
| `api-automation-kit/` | 4 API agents (inventory, journey, test-builder, runner) + API Studio (own Postman: UI + CLI) | `KITS-SETUP.md` Part 1-3 |
| `springboot-vscode-kit/` | spring-vscode agent + .vscode templates to run/debug Spring Boot in VS Code instead of IntelliJ | `KITS-SETUP.md` Part 4 |

Install order: core kit first (`FINAL-SETUP.md` Part A), then the other two (`KITS-SETUP.md`).
All agents/prompts go to `C:\copilot-kit\agents` and `C:\copilot-kit\prompts`; nothing needs to be committed to a repo.
