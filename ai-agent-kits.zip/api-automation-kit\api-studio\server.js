'use strict';
// API Studio: local Postman-like UI. Config once, import OpenAPI/Postman/JSON/XML, run journeys, see results, copy curl.
const express = require('express');
const fs = require('fs');
const path = require('path');
const { loadConfig, runJourney, saveReport, toCurl } = require('./lib/runner');
const { detectAndImport } = require('./lib/importers');
const { mask } = require('./lib/vars');

const app = express();
app.use(express.json({ limit: '20mb' }));
app.use(express.text({ limit: '20mb', type: ['text/*', 'application/xml', 'application/yaml'] }));
app.use(express.static(path.join(__dirname, 'public')));

const configPath = path.join(__dirname, 'config', 'config.json');
const examplePath = path.join(__dirname, 'config', 'config.example.json');
const journeysDir = process.env.JOURNEYS_DIR || path.join(__dirname, 'journeys');
const reportsDir = path.join(__dirname, 'reports');
fs.mkdirSync(journeysDir, { recursive: true });

const readJourneys = () => fs.readdirSync(journeysDir).filter((f) => f.endsWith('.json')).map((f) => ({ file: f, ...JSON.parse(fs.readFileSync(path.join(journeysDir, f), 'utf8')) }));

app.get('/api/config', (req, res) => {
  const p = fs.existsSync(configPath) ? configPath : examplePath;
  res.json(JSON.parse(fs.readFileSync(p, 'utf8')));   // raw (with env:NAME refs), not resolved; UI edits it
});
app.post('/api/config', (req, res) => { fs.writeFileSync(configPath, JSON.stringify(req.body, null, 2)); res.json({ ok: true }); });

app.get('/api/journeys', (req, res) => res.json(readJourneys()));
app.post('/api/journeys', (req, res) => {
  const j = req.body; if (!j.name || !Array.isArray(j.steps)) return res.status(400).json({ error: 'name and steps required' });
  const file = path.join(journeysDir, `${j.name.replace(/[^\w-]+/g, '_')}.journey.json`);
  fs.writeFileSync(file, JSON.stringify(j, null, 2)); res.json({ ok: true, file: path.basename(file) });
});
app.delete('/api/journeys/:file', (req, res) => { const f = path.join(journeysDir, path.basename(req.params.file)); if (fs.existsSync(f)) fs.unlinkSync(f); res.json({ ok: true }); });

app.post('/api/import', (req, res) => {
  try {
    const filename = req.query.filename || 'import';
    const text = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
    const js = detectAndImport(text, filename);
    const saved = [];
    for (const j of js) { const f = path.join(journeysDir, `${j.name.replace(/[^\w-]+/g, '_')}.journey.json`); fs.writeFileSync(f, JSON.stringify(j, null, 2)); saved.push({ file: path.basename(f), steps: j.steps.length }); }
    res.json({ ok: true, saved });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.post('/api/run', async (req, res) => {
  try {
    const { journey, mock, only, vars } = req.body;
    const j = readJourneys().find((x) => x.name === journey || x.file === journey);
    if (!j) return res.status(404).json({ error: 'journey not found' });
    const config = loadConfig(fs.existsSync(configPath) ? configPath : examplePath);
    const report = await runJourney(j, config, { mock: !!mock, only, vars });
    const file = saveReport(report, reportsDir);
    res.json({ ...report, file: path.basename(file) });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

app.post('/api/curl', (req, res) => {
  try {
    const { journey, step } = req.body;
    const j = readJourneys().find((x) => x.name === journey || x.file === journey);
    const config = loadConfig(fs.existsSync(configPath) ? configPath : examplePath);
    const vars = { ...(config.vars || {}), baseUrl: config.baseUrl, ...(j.vars || {}) };
    const s = j.steps[step];
    res.json({ curl: toCurl({ ...s.request, headers: { ...(config.headers || {}), ...(s.request.headers || {}) } }, vars), masked: toCurl({ ...s.request, headers: { ...(config.headers || {}), ...(s.request.headers || {}) } }, vars, { maskSecrets: true }) });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

app.get('/api/reports', (req, res) => { fs.mkdirSync(reportsDir, { recursive: true }); res.json(fs.readdirSync(reportsDir).filter((f) => f.endsWith('.json')).sort().reverse().slice(0, 50)); });
app.get('/api/reports/:file', (req, res) => res.json(mask(JSON.parse(fs.readFileSync(path.join(reportsDir, path.basename(req.params.file)), 'utf8')))));

const port = process.env.PORT || 4545;
app.listen(port, '127.0.0.1', () => console.log(`API Studio on http://localhost:${port}  journeys: ${journeysDir}`));
