---
description: Build executable API journeys from the inventory
agent: api-journey
---
Build journeys for: ${input:journey:a journey name, a description, or "all"}
Use api/inventory.json, chain data between steps with extract/assert, add DB checks where endpoints write tables,
add teardown for created data, and write api/JOURNEYS.md with coverage.
