#!/usr/bin/env node
'use strict';
// node cli.js run <journey> [--all] [--config path] [--mock] [--journeys dir] [--junit file] [--var k=v]
// node cli.js curl <journey> --step <n> [--config path]
// node cli.js import <file> [--journeys dir]
const fs = require('fs');
const path = require('path');
const { loadConfig, runJourney, saveReport, toJUnit, toCurl } = require('./lib/runner');
const { detectAndImport } = require('./lib/importers');
const { substitute } = require('./lib/vars');

const args = process.argv.slice(2);
const cmd = args[0];
const opt = (name, def) => { const i = args.indexOf(`--${name}`); return i >= 0 ? args[i + 1] : def; };
const flag = (name) => args.includes(`--${name}`);
const root = __dirname;
const journeysDir = path.resolve(opt('journeys', path.join(root, 'journeys')));
const configPath = path.resolve(opt('config', path.join(root, 'config', 'config.json')));
const reportsDir = path.join(root, 'reports');

function loadJourneys(name) {
  const files = fs.readdirSync(journeysDir).filter((f) => f.endsWith('.json'));
  const all = files.map((f) => JSON.parse(fs.readFileSync(path.join(journeysDir, f), 'utf8')));
  if (!name || name === '--all') return all;
  const j = all.find((x) => x.name === name) || all.find((x) => path.basename(files[all.indexOf(x)], '.json').replace('.journey', '') === name);
  if (!j) throw new Error(`journey "${name}" not found in ${journeysDir}`);
  return [j];
}

(async () => {
  try {
    if (cmd === 'run') {
      const name = flag('all') ? '--all' : args[1];
      const config = fs.existsSync(configPath) ? loadConfig(configPath) : { baseUrl: 'http://localhost', vars: {} };
      const vars = {};
      for (let i = 0; i < args.length; i++) if (args[i] === '--var') { const [k, v] = args[i + 1].split('='); vars[k] = v; }
      const reports = [];
      let failed = 0;
      for (const j of loadJourneys(name)) {
        const r = await runJourney(j, config, { mock: flag('mock'), vars });
        reports.push(r);
        const file = saveReport(r, reportsDir);
        console.log(`\n${r.ok ? 'PASS' : 'FAIL'}  ${j.name}  (${file})`);
        for (const s of [...r.steps, ...r.teardown]) {
          console.log(`  ${s.ok ? 'ok  ' : 'FAIL'} ${s.name}  ${s.status ?? ''} ${s.ms ?? ''}ms${s.error ? '  ' + s.error : ''}`);
          for (const a of s.asserts || []) if (!a.ok) console.log(`       x ${a.check} (actual: ${JSON.stringify(a.actual)})`);
          if (s.dbCheck && !s.dbCheck.ok) console.log(`       x db: ${s.dbCheck.reason}`);
          if (!s.ok && s.dependsOn?.length) console.log(`       depends on: ${s.dependsOn.join(', ')}`);
        }
        if (!r.ok) failed++;
      }
      const junit = opt('junit');
      if (junit) { fs.writeFileSync(junit, toJUnit(reports)); console.log(`JUnit written to ${junit}`); }
      process.exit(failed ? 1 : 0);
    } else if (cmd === 'curl') {
      const [j] = loadJourneys(args[1]);
      const step = j.steps[Number(opt('step', 0))];
      const config = fs.existsSync(configPath) ? loadConfig(configPath) : { baseUrl: 'http://localhost', vars: {} };
      const vars = { ...(config.vars || {}), baseUrl: config.baseUrl, ...(j.vars || {}) };
      console.log(toCurl({ ...step.request, headers: { ...(config.headers || {}), ...(step.request.headers || {}) } }, vars));
    } else if (cmd === 'import') {
      const file = args[1];
      const js = detectAndImport(fs.readFileSync(file, 'utf8'), path.basename(file));
      fs.mkdirSync(journeysDir, { recursive: true });
      for (const j of js) { const out = path.join(journeysDir, `${j.name.replace(/[^\w-]+/g, '_')}.journey.json`); fs.writeFileSync(out, JSON.stringify(j, null, 2)); console.log(`imported -> ${out} (${j.steps.length} steps)`); }
    } else {
      console.log('usage: cli.js run <journey>|--all [--config f] [--mock] [--junit f] [--var k=v] | curl <journey> --step n | import <file>');
    }
  } catch (e) { console.error('ERROR', e.message); process.exit(2); }
})();
