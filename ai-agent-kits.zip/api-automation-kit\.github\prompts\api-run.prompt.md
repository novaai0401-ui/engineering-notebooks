---
description: Run a journey end to end with the local config and explain failures
agent: api-runner
---
Run journey ${input:journey:journey name or --all} using api-studio/config/config.json. Report PASS/FAIL per step,
explain failures with downstream dependencies, and give the curl for the first failing step.
