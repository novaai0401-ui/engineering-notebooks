# API Automation Kit

Four Copilot agents plus a local Postman-like app (API Studio). Any run produces a FRESH inventory of every API the
repo serves and every third-party / internal API it calls, maps which depends on which, builds journeys, generates
automated tests, and runs a selected journey end to end from one configuration (headers, token, base URLs, DB).

## Agents (4)

| Agent | Command | Produces |
|-------|---------|----------|
| api-inventory | `/api-inventory` | `api/inventory.json`, `api/INVENTORY.md`: exposed endpoints, consumed APIs (third-party / internal), config keys, DB tables, dependency map. Regenerated from scratch every run. |
| api-journey | `/api-journey <name or all>` | `api/journeys/*.journey.json`, `api/JOURNEYS.md` (coverage) |
| api-test-builder | `/api-tests` | `api/tests/`: code suite (Jest or JUnit+RestAssured), Postman collection + environment, curl scripts (bash + PowerShell), run.ps1 / run.sh |
| api-runner | `/api-run <journey>` | runs via API Studio CLI, report with PASS/FAIL per step, failing step curl, downstream dependencies |

`/api-all <journey>` chains all four.

## API Studio (manual + CLI)

```
cd api-studio
npm install
npm start            # http://localhost:4545
```
Tabs: 1 Config (once: base URL, headers, auth bearer or login request, variables, DB), 2 Import (OpenAPI json/yaml,
Postman v2.1, journey JSON, XML: SOAP envelope or `<journey>` format), 3 Journeys (edit JSON), 4 Run (live or mock,
single step or all, results table with copy-curl per step), 5 Reports.

CLI (same engine, for automation / CI):
```
node cli.js run example-orders --config config/config.json
node cli.js run --all --junit reports/junit.xml
node cli.js run example-orders --mock              # no network, uses mocks/<step>.json
node cli.js curl example-orders --step 0           # curl for one step, fully resolved
node cli.js import ../openapi.yaml                 # file -> journeys/
```
Config values of the form `env:NAME` are read from the environment at run time, so secrets stay out of the file.
With the Copilot kit vault: `powershell -File C:\copilot-kit\secrets.ps1 env` first, then run.

## Journey format
See `api-studio/journeys/example-orders.journey.json`: steps with `request`, `extract` (JSONPath or `header:Name`),
`assert` (`status`, `path` + `equals|exists|contains|matches`, `maxMs`), optional `db` (`query`, `expect`),
`dependsOn` (downstream API ids), and `teardown`.

## Install the agents
Copy `.github/agents/*` and `.github/prompts/*` into the repo's `.github/` or into `C:\copilot-kit\agents` and
`C:\copilot-kit\prompts` (user-level, see the main kit). Reload VS Code. Agents appear in the Agent dropdown.

## Guardrails
- Inventory and config never contain secret values; placeholders and `env:` references only.
- Runner refuses base URLs that look like production unless `allowProd` is true.
- Reports and curl output mask Authorization, tokens, api keys and DB passwords.
- Agents never modify application source; outputs live under `api/` and `api-studio/`.
