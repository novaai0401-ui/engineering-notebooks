---
description: Build, run the local profile, smoke-test, and optionally run an API journey
agent: spring-vscode
---
Compile, start the app with profile ${input:profile:local}, wait for "Started", call the health endpoint, report the
result, then ${input:journey:optionally run API journey <name>, or "none"}. Stop the app at the end unless I say keep.
