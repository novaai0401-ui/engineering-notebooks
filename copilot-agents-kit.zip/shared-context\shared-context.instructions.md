---
applyTo: "**"
---
# Shared project context (links the frontend and backend VS Code windows)

The shared folder for this project is: `C:\copilot-kit\context\<PROJECT>\`
(replace <PROJECT> with the project name; both repos point at the same folder).

On every task, AFTER reading the repo's own CONTEXT.md:
1. Read `C:\copilot-kit\context\<PROJECT>\PROJECT.md` (cross-repo conventions, repo paths, open cross-repo work).
2. Read `C:\copilot-kit\context\<PROJECT>\contracts.md` (API contracts and shared types).

Rules:
- Backend agents (`api-dev`, `feature-loop` on backend files): when you add or change an endpoint, update `contracts.md`
  in the same task (status planned -> implemented, request/response shape, consumers, change log line).
- Frontend agents (`ui-dev`, `feature-loop` on UI files): call only endpoints and fields present in `contracts.md`.
  If the UI needs something missing, add it to `contracts.md` as `planned` with today's date and tell the user the backend
  window must implement it. Do not fake data to get around it.
- Both: when a task spans both repos, append a line under "Open cross-repo work" in PROJECT.md with status, and update it
  when your side is done.
- If you need code from the other repo, read it from the local path listed in PROJECT.md "Repo map"; do not guess.
- Never write secrets, tokens or real URLs with credentials into any shared file.
