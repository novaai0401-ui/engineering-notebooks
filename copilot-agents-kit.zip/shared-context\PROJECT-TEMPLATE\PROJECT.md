# Shared project context - <project name>
Owner repos: frontend = <repo url or local path> | backend = <repo url or local path>
Last updated: <date> by <frontend|backend> agent

## What this project is
- One paragraph. Users, main flows, environments (dev / uat / prod).

## Repo map
| Repo | Local path | Stack | Context file |
|------|-----------|-------|--------------|
| frontend | C:\work\shop-ui | Next.js 15, React 19, Redux Toolkit | C:\work\shop-ui\.github\copilot-context\CONTEXT.md |
| backend | C:\work\shop-api | Node 20, Express, Prisma | C:\work\shop-api\.github\copilot-context\CONTEXT.md |

## Cross-repo conventions
- Auth: bearer JWT in `Authorization` header, refreshed by frontend via `POST /auth/refresh`.
- Errors: `{ code: string, message: string, details?: object }`, HTTP status per REST.
- Pagination: `?page=1&size=20` -> `{ items, page, size, total }`.
- Dates: ISO-8601 UTC strings.
- Feature flags: name list in `contracts.md` section "Flags".

## Environments
| Env | Frontend URL (no secrets) | API base path |
|-----|---------------------------|---------------|

## Open cross-repo work
- YYYY-MM-DD: <ticket> - backend adds X, frontend consumes X. Status: backend done / frontend pending.
