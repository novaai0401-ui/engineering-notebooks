## Overview
Implement ONE ticket on a fresh branch from the named feature branch, verify it, open a PR into that feature branch, and stop. Starts from the machine snapshot; never re-installs the project. Fill in before starting: repo, base feature branch, ticket id, task description.

## Procedure
1. **Start from snapshot**: do not reinstall dependencies unless the lockfile changed and `pnpm install` is required.
2. **Branch**: `git fetch origin <base_branch> --depth=50 && git checkout -b devin/<ticket>-<short-slug> origin/<base_branch>`.
3. **Load context**: read `.github/copilot-context/CONTEXT.md` (or the Knowledge entry "<repo> project context"). Open only the files the task needs; grep for symbols instead of reading folders.
4. **Define done**: post 3-6 checkable acceptance criteria in one message and continue without waiting unless something is unclear.
5. **Implement**: follow CONTEXT.md conventions, minimal diff, no reformatting, no unrelated files, reuse existing components and services.
6. **Test**: add or update tests for the change, then run typecheck, lint and the unit tests for touched packages only.
7. **Log**: append one line under "## Recent changes" in CONTEXT.md and include it in the same commit.
8. **Commit and push**: message `<ticket>: <summary>`, push the `devin/...` branch.
9. **Open PR into <base_branch>**: body contains summary, criteria PASS/FAIL table, commands run with results, screenshots for UI.
10. **Stop**: reply with the PR link, do not wait for CI, do not start other work, end the session.

## Advice & Pointers
- Keep the diff under about 300 lines; if the task is bigger, split it, do the first part, and say what remains.
- If a check fails on code you did not touch, note it in the PR body and continue; do not fix unrelated failures.
- If information is missing, ask one precise question with options, then wait.
- Env var and secret names come from CONTEXT.md and Secrets; never print values.

## Forbidden actions
- Pushing to main or directly to the feature branch. Merging. Force-pushing.
- Re-running environment setup or installing global tools.
- Weakening, skipping or deleting tests to get a pass.
- Waiting for CI, polling pipelines, or opening a second PR in the same session.
- Writing secrets, tokens or credentials into any file or the PR.
