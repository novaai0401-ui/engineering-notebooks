---
applyTo: "{.tekton,tekton,pipelines,.harness,harness,k8s,kubernetes,manifests,helm,charts,openshift,deploy}/**/*.{yaml,yml},**/Dockerfile*,**/kustomization.yaml,**/skaffold.yaml"
---
- Pin images by tag + digest where the repo already does; never `latest`.
- Workloads: resource requests/limits, readiness + liveness probes, `runAsNonRoot: true`, drop all capabilities.
- Secrets only by reference (Harness `<+secrets.getValue()>`, K8s `secretKeyRef`, external/sealed secrets). No literals.
- Harness: env-specific values via `<+input>` / variables; keep identifiers stable.
- Tekton: declare params/workspaces/results before use; prefer catalog tasks; set `timeout`s.
- Helm: edit `values-<env>.yaml` first; bump `Chart.yaml` version on template changes.
- Do not reorder or reformat existing YAML; keep comments.
