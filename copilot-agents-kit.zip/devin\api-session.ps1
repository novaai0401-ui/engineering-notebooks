# Start a Devin session from a playbook without opening the UI.
# Requires a Devin API key in the environment: $env:DEVIN_API_KEY (Settings > API keys). Never hardcode it.
# Usage:
#   .\api-session.ps1 -Playbook "pr-per-task" -Repo "org/shop-ui" -Base "feature/orders" -Ticket "SHOP-123" -Task "Add CSV export to Orders table"
param(
  [Parameter(Mandatory)] [string]$Playbook,
  [Parameter(Mandatory)] [string]$Repo,
  [Parameter(Mandatory)] [string]$Base,
  [Parameter(Mandatory)] [string]$Ticket,
  [Parameter(Mandatory)] [string]$Task,
  [string]$Snapshot = ""     # optional machine snapshot id
)
if (-not $env:DEVIN_API_KEY) { Write-Error "Set DEVIN_API_KEY first"; exit 1 }

$prompt = @"
Use playbook '$Playbook'.
Repo: $Repo
Base branch: $Base
Ticket: $Ticket
Task: $Task
Start from the machine snapshot. Open a PR into $Base and stop.
"@

$body = @{ prompt = $prompt; idempotent = $true }
if ($Snapshot) { $body.snapshot_id = $Snapshot }

$resp = Invoke-RestMethod -Method Post -Uri "https://api.devin.ai/v1/sessions" `
  -Headers @{ Authorization = "Bearer $env:DEVIN_API_KEY" } `
  -ContentType "application/json" -Body ($body | ConvertTo-Json -Depth 5)

Write-Output "Session: $($resp.session_id)  URL: $($resp.url)"
# Check the API docs for the exact field names if the request is rejected; playbook_id and snapshot_id are
# accepted on current versions of the API.
