---
description: Resume an unfinished feature-loop run from its run file
agent: feature-loop
---
Resume the run file: ${input:runfile:.github/copilot-context/runs/<file>.md}

Read the run file, skip phases already marked complete, re-run Phase 4 verification first,
then continue iterating until all acceptance criteria PASS or the retry budget is spent.
