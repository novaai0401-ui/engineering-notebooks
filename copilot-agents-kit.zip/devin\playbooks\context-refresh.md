## Overview
Refresh the repo's `.github/copilot-context/CONTEXT.md` and branch file after big merges so every later session can read it instead of exploring. Updates only stale sections. Fill in before starting: repo and branch.

## Procedure
1. **Boot and sync**: start from the snapshot, `git fetch origin <branch> && git checkout <branch> && git pull`.
2. **Read the existing file**: open CONTEXT.md and note its "Last updated" and sections.
3. **Check manifests**: compare `package.json` scripts and dependencies, `tsconfig*`, `next.config.*`, `webpack.config.*`, pipeline folders against the Stack and Commands sections.
4. **Check folder map**: list the top two levels, skipping `node_modules`, `dist`, `.next`, `coverage`; update only changed entries.
5. **Sample conventions**: open ONE file per category (component, hook, store slice, route, service, test) and update Conventions only if they changed.
6. **Update the branch file**: write `.github/copilot-context/branches/<branch>.md` (purpose, files changed vs base, open TODOs), max 40 lines.
7. **Enforce limits**: CONTEXT.md under 250 lines; env var names only; trim "Recent changes" to the latest 15.
8. **Commit and push**: `chore(context): refresh CONTEXT.md` on branch `devin/context-refresh-<date>`, open a PR into <branch>.
9. **Echo for Knowledge**: paste the final Conventions, Commands and Key reusable pieces sections in chat so the Devin Knowledge entry can be updated.
10. **Stop**: post the PR link and end the session.

## Advice & Pointers
- If nothing changed in a section, leave it untouched; small diffs make the PR reviewable.
- Bullet lists and tables, not prose.

## Forbidden actions
- Writing secret values, tokens, cluster URLs or credentials.
- Modifying any source file; only files under `.github/copilot-context/`.
- Reading the whole repository; manifests plus one sample per category only.
