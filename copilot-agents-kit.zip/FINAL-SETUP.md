# Final setup, start to finish

Order matters. Part A once per laptop, Part B once per repo, Part C once in Devin, Part D daily.

## Part A: laptop (once, ~15 min)

1. Extract `copilot-agents-kit.zip` somewhere temporary.
2. Create `C:\copilot-kit\` and copy into it:
   - `.github\agents\`            -> `C:\copilot-kit\agents\`
   - `.github\prompts\`           -> `C:\copilot-kit\prompts\`
   - `.github\instructions\`      -> `C:\copilot-kit\instructions\`
   - `shared-context\shared-context.instructions.md` -> `C:\copilot-kit\instructions\`
   - `.github\copilot-instructions.md`               -> `C:\copilot-kit\copilot-instructions.md`
   - `vscode-user-settings\secrets.ps1`              -> `C:\copilot-kit\secrets.ps1`
   - `devin\`                                        -> `C:\copilot-kit\devin\`   (reference only, pasted into Devin later)
   - `shared-context\PROJECT-TEMPLATE\`              -> `C:\copilot-kit\context\_TEMPLATE\`
3. VS Code: `Ctrl+Shift+X`, install **GitHub Copilot** (installs Copilot Chat too). Sign in with the org GitHub account via the popup.
4. `Ctrl+Shift+P` -> `Preferences: Open User Settings (JSON)`. Add inside the outer braces:
   ```json
   "chat.agent.enabled": true,
   "github.copilot.chat.codeGeneration.useInstructionFiles": true,
   "chat.agentFilesLocations": { "C:\\copilot-kit\\agents": true },
   "chat.promptFilesLocations": { "C:\\copilot-kit\\prompts": true },
   "chat.instructionsFilesLocations": { "C:\\copilot-kit\\instructions": true },
   "github.copilot.chat.codeGeneration.instructions": [ { "file": "C:\\copilot-kit\\copilot-instructions.md" } ]
   ```
5. `Ctrl+Shift+P` -> `Developer: Reload Window`.
6. `Ctrl+Alt+I` -> click the **Ask** dropdown -> choose **Agent** -> open the dropdown again and confirm these are listed:
   context-builder, setup, product, feature-loop, ui-dev, api-dev, java-dev, devops, reviewer, planner.
7. Secrets vault, first value (hidden prompt; repeat for each token / password you know you need):
   ```
   powershell -File C:\copilot-kit\secrets.ps1 set NPM_TOKEN
   ```

## Part B: each repo (once per repo, ~20 min the first time)

1. Clone the repo, open the folder in VS Code.
2. Keep the context local: open `.git\info\exclude` in Notepad, add the line `.github/copilot-context/`.
3. `Ctrl+Alt+I`, Agent mode, pick **setup**, type `/ide-sync` -> mode `baseline`. (Snapshot of IDE/config before you touch anything.)
4. Do your normal manual setup if the project has never run on this laptop (registry login, proxy, JDK, run configs...).
5. Pick **setup**, `/record-setup` -> project name. Answer its checklist once. It stores passwords in the vault and writes `SETUP.md`.
6. Pick **setup**, `/ide-sync` -> mode `diff`. Only the IDE/config changes you made become steps in `SETUP.md`.
7. Pick **context-builder**, `/update-context`. Approve the commands. It writes `CONTEXT.md` and the branch file.
8. Open `.github\copilot-context\CONTEXT.md`, skim, fix anything wrong by hand.
9. Multi-repo project (frontend + backend): copy `C:\copilot-kit\context\_TEMPLATE\` to `C:\copilot-kit\context\<PROJECT>\`,
   fill the Repo map with real local paths, and replace `<PROJECT>` inside `C:\copilot-kit\instructions\shared-context.instructions.md`.
10. Java repo: nothing extra; `/update-context` detects Maven/Gradle and `/java-task` is available.

## Part C: Devin web app (once, ~30 min; then 5 min per repo)

1. **Secrets**: Settings -> Secrets -> add every name from `SETUP.md` (NPM_TOKEN, HTTPS_PROXY, ...). Same names as the laptop vault, values typed by you.
2. **Knowledge**: Settings -> Knowledge -> Add. For each file in `C:\copilot-kit\devin\knowledge\`:
   title = the `## Name` line, trigger field = `## Trigger` text, body = `## Content` + `## Forbidden`.
   - 01, 02, 03, 07, 08: once, scope = all repos.
   - 04, 05, 06: once per repo, replace `<repo>`, paste that repo's CONTEXT.md / SETUP.md sections, scope = that repo.
3. **Playbooks**: Playbooks -> New -> select all in the editor, paste one file from `C:\copilot-kit\devin\playbooks\`, name it after the file, Save.
   Repeat for: product-4d, pr-per-task, batch-prs, feature-loop, context-refresh, zip-onboard, multi-repo-workspace.
4. **Machine, connected repo**: Settings -> Repositories -> Add -> fill Install / Maintain / Lint / Tests / Run app from `SETUP.md`
   using `$SECRET_NAME` for credentials -> click Test on each -> Snapshot.
5. **Machine, not connected repo**: on the laptop, in the repo (context files included, no node_modules):
   ```
   powershell -Command "Compress-Archive -Path * -DestinationPath ..\repo.zip -Force"
   ```
   New session -> playbook `zip-onboard` -> attach the zip, project name, commit SHA -> add Secrets it asks for -> repeat in the same
   session for the other repos of the project -> when it says "ready to snapshot": Settings -> Repositories -> that machine -> Snapshot.
6. **CI gate** (once per repo, in your pipeline config, so you stop killing pipelines by hand): add the `devin/*` branch filter from
   `C:\copilot-kit\devin\ci\` (GitHub Actions, Tekton CEL, or Harness trigger condition).
7. Settings -> enable **Interactive Planning**.

## Part D: daily loop

Copilot (VS Code chat, type `/` to see commands):
- New requirement -> `/spec` (4D: stories, Given/When/Then criteria, test cases, Touch lists).
- Build -> `/feature <goal>` (loop until criteria pass) or `/ui-task`, `/api-task`, `/java-task`, `/pipeline` for one small change.
- Before PR -> `/review`.
- Switched branch -> `/update-context`. Changed an IDE/config setting that mattered -> `/ide-sync diff`.
- New laptop -> `secrets.ps1 export` / `import`, clone, `/setup`.

Devin (browser):
- Questions / "where is X" -> Ask Devin / DeepWiki tab (no session, no ACU).
- New requirement -> session with `product-4d` -> spec PR -> End session.
- One ticket -> `pr-per-task`; several small -> `batch-prs`; whole feature -> `feature-loop`; zipped repo -> `multi-repo-workspace`.
  Fill repo, base feature branch, ticket, task. Approve the plan. **End the session when the PR link (or patch files) appears.**
- Zipped repo result: download patches ->
  ```
  git checkout -b devin/<ticket> <base>   ;  git am out\*.patch   ;  git push -u origin devin/<ticket>
  ```
  then open the PR yourself.
- After big merges -> `context-refresh` session (or `/update-context` locally + new zip/patch), then paste changed sections into
  the "<repo> project context" Knowledge entry.
- Re-snapshot only when a lockfile or tool version changes.

## Checks that it is working

- VS Code: agents show in the Agent dropdown; `/` lists the prompts; `.github\copilot-context\CONTEXT.md` exists and `git status` does not show it.
- Devin: Knowledge entries listed; playbooks in the session dropdown; a `pr-per-task` session boots without running install and opens a PR into the feature branch.
- A second session on the same repo reads CONTEXT.md and the slice, not the whole repo (watch the first few actions).

## What counts in the Devin score
Only PRs Devin opens itself on a connected repo. Patch-based work from zips does not count. Start the access process for the 2-3 repos that matter most; use zips for the rest.
