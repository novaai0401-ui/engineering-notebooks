---
description: Review the current branch diff against repo conventions
agent: reviewer
---
Review the current branch diff against the base branch and CONTEXT.md conventions. Report a severity table and a verdict.
