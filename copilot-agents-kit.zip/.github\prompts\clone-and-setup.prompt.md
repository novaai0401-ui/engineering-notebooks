---
description: Clone a repo into a folder, then replay its SETUP.md from the shared context folder
agent: setup
---
MODE: REPLAY from scratch.
1. Run: `git clone ${input:url:repo clone url} ${input:dir:target folder}` and tell me to open that folder in VS Code if the
   clone succeeded (you cannot change the workspace yourself).
2. If I am already in the cloned folder, read `C:\copilot-kit\context\${input:project:project name}\SETUP.md` (fallback to
   the repo's `.github/copilot-context/SETUP.md`) and replay it fully: preflight, steps with verify, run, smoke test, log.
