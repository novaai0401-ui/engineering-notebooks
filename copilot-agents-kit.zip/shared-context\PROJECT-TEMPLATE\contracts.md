# API contracts - <project name>
Rule: the BACKEND agent edits this file when it adds or changes an endpoint.
      The FRONTEND agent reads it and must not invent fields that are not here.
      Each endpoint has a status: planned | implemented | deprecated.

## Endpoints

### GET /orders  - implemented
Query: page (int, default 1), size (int, 1-100, default 20), status? (enum: NEW|PAID|SHIPPED)
200: { items: Order[], page, size, total }
401: unauthenticated  403: not allowed
Consumers: frontend `src/features/orders/api.ts`

### POST /orders/{id}/cancel  - planned (2026-10-11, ticket SHOP-123)
Body: { reason: string (1-200) }
200: Order   409: already shipped
Consumers: frontend OrdersTable row action (pending)

## Types
```ts
type Order = {
  id: string;
  status: 'NEW' | 'PAID' | 'SHIPPED' | 'CANCELLED';
  total: number;        // minor units
  currency: string;     // ISO 4217
  createdAt: string;    // ISO-8601 UTC
};
```

## Flags
- `orders.cancel` - enables cancel action (backend checks, frontend hides button)

## Change log
- 2026-10-11 backend: added POST /orders/{id}/cancel (planned)
