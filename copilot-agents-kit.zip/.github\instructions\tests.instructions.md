---
applyTo: "**/*.{test,spec}.{ts,tsx,js,jsx}"
---
- Arrange / Act / Assert with descriptive `it("should ...")` names.
- No real network, timers or DB; mock at the module boundary the repo already uses.
- One behaviour per test; prefer `screen.getByRole` over test ids in UI tests.
- Do not change existing assertions to make a test pass; fix the code or explain why the assertion was wrong.
