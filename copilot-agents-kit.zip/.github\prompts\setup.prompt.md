---
description: "Replay SETUP.md on this machine - install tools, configure registry and proxy, install deps, run and smoke-test"
agent: setup
---
MODE: REPLAY for project ${input:project:project name}.
Read SETUP.md (repo copy, else `C:\copilot-kit\context\<project>\SETUP.md`), run preflight, execute each step with its verify
command, use "Known errors" on failure, stop and tell me exactly what to do for anything needing secrets or admin rights,
then run the smoke test and update "Last verified" and the setup log.
