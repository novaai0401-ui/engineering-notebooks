---
description: Record this project's real setup steps into SETUP.md (run once, on a machine where it works or while you set it up)
agent: setup
---
MODE: RECORD.
Discover tools, registries, proxies, certs and env var NAMES from this repo and this machine, ask me only for what you cannot
discover, run install/build/dev/test yourself, capture every error and the fix that worked, and write SETUP.md to
`.github/copilot-context/SETUP.md` and to `C:\copilot-kit\context\${input:project:project name}\SETUP.md`.
