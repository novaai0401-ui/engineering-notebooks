# Copilot Agents Kit - context-first agents for VS Code

Goal: stop paying tokens to re-learn the same project in every chat and every repo.
One agent builds a compact **CONTEXT.md** per repo/branch; every other agent reads
that file first and only opens what the task needs.

## What is inside

| Path | Purpose |
|------|---------|
| `.github/copilot-instructions.md` | Global rules for every chat: read CONTEXT.md first, minimal diffs, run checks, log changes |
| `.github/agents/context-builder.agent.md` | Scans repo once, writes/updates `CONTEXT.md` + `branches/<branch>.md` |
| `.github/agents/ui-dev.agent.md` | Front-end implementer (React / Next.js / TS) |
| `.github/agents/api-dev.agent.md` | Backend implementer (Node / TS) |
| `.github/agents/java-dev.agent.md` | Backend implementer (Java / Spring Boot, Maven or Gradle) |
| `.github/agents/reviewer.agent.md` | Read-only reviewer of the branch diff |
| `.github/agents/planner.agent.md` | Read-only planner for bigger features |
| `.github/agents/devops.agent.md` | Tekton / Harness / K8s-OpenShift / Helm / Docker changes, validated with dry-runs, never deploys |
| `.github/agents/setup.agent.md` | Records project setup once (`/record-setup`), replays it on a fresh clone (`/setup`, `/clone-and-setup`) |
| `.github/agents/feature-loop.agent.md` | **Autonomous loop**: criteria -> design -> develop -> test -> verify -> repeat (max 5) |
| `.github/prompts/*.prompt.md` | Slash commands: `/update-context`, `/feature`, `/resume-feature`, `/ui-task`, `/api-task`, `/java-task`, `/pipeline`, `/review`, `/record-setup`, `/setup`, `/clone-and-setup`, `/ide-sync` |
| `.github/instructions/*.instructions.md` | File-type rules auto-applied when Copilot edits matching files |
| `.github/copilot-context/CONTEXT.md` | The shared memory file (template; agent fills it) |
| `devin/` | Devin playbooks, Knowledge entries, CI gates for devin/* branches, zip/patch workflow, API launcher (see devin/README.md) |
| `vscode-user-settings/settings.snippet.json` | User-level setup when you cannot commit to repos |

## How it saves tokens

- **One expensive scan, many cheap chats.** `context-builder` reads manifests and one sample file per category, then writes a <=250-line summary. Every later chat loads that summary (~2-3k tokens) instead of running `#codebase` searches and opening dozens of files.
- **Branch awareness.** `branches/<branch>.md` records what the branch is for and what changed vs base, so switching branches is a 40-line refresh, not a full re-scan.
- **Scoped tools.** Reviewer/planner cannot edit; implementers are told to open only needed files and use `usages` instead of broad search.
- **Self-updating memory.** Implementers append to "Recent changes" in CONTEXT.md, so the next chat already knows what you did.

## Install - Option A: inside each repo (preferred if you can commit)

1. Copy the `.github` folder into the repo root (merge if `.github` already exists).
2. In VS Code: Settings -> search `chat.agent.enabled` -> on. Also enable
   `github.copilot.chat.codeGeneration.useInstructionFiles`.
3. Open Copilot Chat (Ctrl+Alt+I), switch mode to **Agent**, pick `context-builder`
   from the agent/mode dropdown, and run `/update-context`.
4. Commit `.github/` so the whole team shares the agents and the context file.

## Install - Option B: user-level (org repos locked down)

1. Create `C:\copilot-kit\` and copy into it:
   - `agents\` (the 5 `*.agent.md` files)
   - `prompts\` (the `*.prompt.md` files)
   - `instructions\` (the `*.instructions.md` files)
   - `copilot-instructions.md`
2. Merge `vscode-user-settings/settings.snippet.json` into your **User** `settings.json`
   (Ctrl+Shift+P -> "Preferences: Open User Settings (JSON)"). Adjust the paths if you used a different folder.
3. Alternative without editing settings: Ctrl+Shift+P -> "Chat: New Agent File" -> choose
   **User data folder**, paste each agent's content. Same for "Chat: New Prompt File" and
   "Chat: New Instructions File". These live in your VS Code profile and work in every repo.
4. The context file still needs to live somewhere the agent can read and write. Two choices:
   - Keep `.github/copilot-context/` in the repo but add it to `.git/info/exclude` (local-only ignore, no commit needed).
   - Or edit `context-builder.agent.md` and change the path to e.g. `C:\copilot-kit\context\<repo-name>\CONTEXT.md`.
     Then also change the same path in `copilot-instructions.md`, `ui-dev`, `api-dev`, `reviewer`, `planner`.

## Daily workflow

```
# first time in a repo (or after a big merge)
Agent: context-builder     ->  /update-context

# switch branch
git checkout feature/x     ->  /update-context     (cheap: only branch file + deltas)

# do work
/ui-task  Add a loading skeleton to the Orders table
/api-task Add pagination (page,size) to GET /orders, keep old clients working

# end-to-end, hands-off: criteria -> design -> build -> test -> verify -> repeat until green
/feature  Users can export the Orders table to CSV, filtered by current date range
/resume-feature .github/copilot-context/runs/2026-10-11-orders-csv.md   # continue a run in a new chat

# pipelines / manifests
/pipeline Add a Harness approval stage before the prod deploy; validate YAML
/pipeline Add readiness probe and resource limits to the orders-api Deployment

# before raising PR
/review
```

Or type `@ui-dev`, `@api-dev`, `@reviewer`, `@planner` in chat to invoke an agent directly.

## Tuning for your stack

- Edit `.github/instructions/*.instructions.md` `applyTo` globs to match your folder layout
  (e.g. micro-frontend remotes under `apps/*/src`).
- If you use Nx/Turbo monorepos, add a line in `context-builder` step 3 to read `project.json` per app.
- For Harness/Tekton/OpenShift repos, the builder already records pipeline folders under
  "Integration points"; add deployment commands to the Commands table if you want agents to run them
  (not recommended - keep deploys manual).
- Model: add `model: "gpt-4.1"` (or whichever your org allows) to an agent's front matter to pin a cheaper
  model for `context-builder` / `reviewer` and a stronger one for implementers.

## How the feature-loop decides it is "done"

1. It converts your request into 3-8 **checkable acceptance criteria** and writes them to
   `.github/copilot-context/runs/<date>-<slug>.md`.
2. Every criterion gets a test or a command whose output proves it.
3. After implementing, it runs typecheck, lint, tests, and marks each criterion PASS/FAIL with evidence.
4. Any FAIL -> root-cause -> fix -> re-verify. Up to 5 iterations, and it stops early if the same criterion fails 3 times.
5. It is forbidden from weakening or deleting tests to get green.
6. The run file is the resumable memory: a new chat can pick up with `/resume-feature`.

## Guardrails already built in

- Agents never store env values or secrets in CONTEXT.md.
- `context-builder` only writes inside `.github/copilot-context/`.
- Implementers never commit, push, or touch CI files unless asked.
- `chat.tools.autoApprove` is left **off** in the settings snippet so terminal commands still prompt you.

## If something does not show up

- Agent dropdown empty: check the file ends in `.agent.md` and the front matter has `name` + `description`.
  Older VS Code versions used `.chatmode.md` under `.github/chatmodes/`; rename if your version is old.
- Prompt not listed: file must end in `.prompt.md`; reload window (Ctrl+Shift+P -> "Developer: Reload Window").
- Instructions ignored: confirm `github.copilot.chat.codeGeneration.useInstructionFiles` is true.

## Linking two VS Code windows (frontend repo + backend repo)

Chats in two windows never share memory, so the link is a **shared folder on disk** that both repos' agents read and write.

```
C:\copilot-kit\context\<PROJECT>\
   PROJECT.md     cross-repo conventions, local path of each repo, open cross-repo work
   contracts.md   API contracts + shared types; backend writes, frontend reads
```

Setup once per project:
1. Copy `shared-context/PROJECT-TEMPLATE` to `C:\copilot-kit\context\<PROJECT>` and fill the Repo map with the real local paths.
2. Copy `shared-context/shared-context.instructions.md` into **both** repos at `.github/instructions/` (or into
   `C:\copilot-kit\instructions\` if you use user-level setup). Replace `<PROJECT>` inside it.
3. Reload both windows.

Flow for a feature that touches both:
- Backend window: `/feature Add POST /orders/{id}/cancel` -> api-dev implements it and marks it `implemented` in contracts.md.
- Frontend window: `/feature Add Cancel action to OrdersTable` -> ui-dev reads contracts.md, uses the exact shape, no guessing.
- Either side can start: if the UI is first, ui-dev writes the endpoint as `planned` in contracts.md and tells you to run the backend side.

Alternative: open both repos in ONE window with `File > Add Folder to Workspace`, then `File > Save Workspace As`.
Agents then see both folders directly and `usages` works across them. You still keep contracts.md as the single source of truth.

## Never rediscover project setup again

Tribal setup knowledge (private registry, proxy, certs, VPN, env var names, the one command nobody documents) is captured once
and replayed by the `setup` agent.

1. On the machine where the project already runs (or while you fight through setup the first time):
   `/record-setup`  -> project name -> the agent inspects repo + machine, asks you only for what it cannot detect, runs
   install/build/dev/test itself, and writes `SETUP.md` to the repo and to `C:\copilot-kit\context\<PROJECT>\SETUP.md`.
   The shared copy survives even if you lose access to the repo.
2. Next time, on any machine:
   `/clone-and-setup` -> url, folder, project -> clones; open the folder; run `/setup` -> it installs tools, configures
   registry/proxy, installs deps, runs the app, runs the smoke test, and fixes SETUP.md if anything drifted.
3. Secrets ARE kept, but encrypted: `C:\copilot-kit\secrets.ps1` is a zero-dependency DPAPI vault (no modules, works with PowerShell Gallery blocked). The agent saves
   values there during record (hidden input), writes only `NAME -> vault:copilot-kit` in SETUP.md, and on replay loads them
   back into `.env`, `.npmrc`, Maven `settings.xml`, run configs. Move vaults between machines with `secrets.ps1 export/import`.

Learning what you changed: `/ide-sync baseline` right after clone, then `/ide-sync diff` once it runs; only the changed
IntelliJ/VS Code/Maven/Gradle settings become numbered steps in SETUP.md.

IDE too: `/ide-sync record` captures IntelliJ project files (.idea), user options (JDKs, proxy host, keymap, plugins), Maven/Gradle
user config and VS Code extensions into `.github/copilot-context/ide/`; `/ide-sync replay` restores them on a new machine and prints
the exact plugin-install and settings-import steps. Passwords, tokens and workspace.xml are never copied.

Tip: after every painful fix during normal work, tell the agent "add this to Known errors in SETUP.md".
