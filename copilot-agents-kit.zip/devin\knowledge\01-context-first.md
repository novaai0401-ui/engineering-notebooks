## Name
Context-first rule (all repos)

## Trigger (when Devin should use this)
Any coding, review or investigation task in any repository.

## Content
Before exploring a repository, read its context file on this machine:
- connected repo: `<repo root>/.github/copilot-context/CONTEXT.md` (the repo root is where Devin cloned it, usually `~/repos/<repo>` or the folder shown in the session file panel)
- zipped / multi-repo machine: `~/repos/<repo>/.github/copilot-context/CONTEXT.md`
- if the file does not exist in either place, use the Knowledge entry named "<repo> conventions" instead

Treat CONTEXT.md as the source of truth for stack, folder map, conventions, commands, reusable pieces and recent changes. Open only the files needed for the task; grep for symbols instead of reading folders. Never re-run environment setup; start from the machine snapshot.

If CONTEXT.md is missing or stale (older than the branch), say so in one line, do a minimal scan (manifests plus one sample file per category), and write or update CONTEXT.md in the same PR.

## Forbidden
- Broad repository exploration when CONTEXT.md exists.
- Re-reading files already read in the session.
