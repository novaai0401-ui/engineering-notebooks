# Copilot repository instructions (applies to every chat in this repo)

## Context-first rule (token saver)
1. Before exploring the codebase, ALWAYS read `.github/copilot-context/CONTEXT.md`.
   If a branch-specific file exists at `.github/copilot-context/branches/<branch>.md`, read it too.
2. Treat those files as the source of truth for stack, folder map, conventions and commands.
   Do NOT run broad `#codebase` searches to rediscover what is already written there.
3. Only open files that are directly needed for the requested change.
4. If the context file is missing or older than the current branch, say so and ask the user
   to run `/update-context` (or do it yourself if you are the `context-builder` agent).

## Working rules
- Follow the conventions in CONTEXT.md (naming, folder placement, state management, API client, error handling, test style).
- Reuse existing components / services / utilities listed in CONTEXT.md before creating new ones.
- Keep diffs minimal and focused on the task. No unrelated refactors or formatting churn.
- After editing, run the lint / typecheck / test commands listed in CONTEXT.md and fix what you broke.
- Never commit, push, or change CI/pipeline files unless explicitly asked.
- When you finish, append a 1-3 line entry under "## Recent changes" in CONTEXT.md
  (date, branch, what changed, which files). Keep that section to the latest 15 entries.

## Answer style
- Short. Lead with what you changed and where. List files touched. Mention commands run and results.
