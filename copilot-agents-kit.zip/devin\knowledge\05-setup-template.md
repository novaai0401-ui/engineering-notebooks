## Name
<repo> setup   (one entry per repo; mirrors SETUP.md so Devin can set up the machine without the file)

## Trigger (when Devin should use this)
Setting up, repairing or verifying the environment for <repo>; filling the repository setup fields; onboarding from a zip.

## Content
Repo: <org>/<repo> | Default branch: <main> | Machine folder: `~/repos/<repo>`
Last verified: <date>

### Tools and versions
| Tool | Required | Check | Install on Devin's machine (Ubuntu) |
|------|----------|-------|-------------------------------------|
| Node | 20.x | node -v | `nvm install 20 && nvm use 20` |
| pnpm | 9.x | pnpm -v | `corepack enable && corepack prepare pnpm@9 --activate` |

### Network and registry
- npm registry: <url>. Login: `npm config set //<host>/:_authToken=$NPM_TOKEN` (NPM_TOKEN is a Devin Secret)
- Proxy: HTTP_PROXY / HTTPS_PROXY / NO_PROXY are Devin Secrets if required.
- Certificates: `export NODE_EXTRA_CA_CERTS=<path>` if the org CA is needed.

### Environment variables (names only, values are Devin Secrets)
| Name | Used by | Where the value comes from |
|------|---------|----------------------------|

### Install
1. `cd ~/repos/<repo>`
2. `pnpm install --frozen-lockfile`   Verify: exit 0, no ERR_ lines

### Run and check
- dev: `pnpm dev` -> http://localhost:<port>
- lint: `pnpm lint`
- typecheck: `pnpm typecheck`
- test: `pnpm test -- --watch=false`
- build: `pnpm build`

### Smoke test
- `curl -sf http://localhost:<port>/health` returns 200 (or: home page renders without console errors)

### Known errors and fixes
- `<exact error text>` -> `<exact fix command>`

## Forbidden
- Printing or storing secret values anywhere.
- Installing tools that need admin rights without asking.
- Re-running install when the snapshot already has dependencies and the lockfile is unchanged.
