---
description: Autonomous design -> develop -> test -> verify loop until acceptance criteria pass
agent: feature-loop
---
Feature request: ${input:request:What should be built or changed, and why}

Run the full loop: write acceptance criteria, design, implement (UI and/or backend as needed),
write tests, run typecheck/lint/tests, verify each criterion, and iterate (max 5) until all pass.
Record everything in a run file and finish with the standard summary.
