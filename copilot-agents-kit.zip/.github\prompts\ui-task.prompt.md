---
description: Implement a front-end change using the saved context
agent: ui-dev
---
Implement this UI change: ${input:task:Describe the UI change}

Constraints:
- Read CONTEXT.md first; do not re-scan the repo.
- Follow repo conventions; reuse existing components.
- Add/update tests, run lint + typecheck + tests, then log the change in CONTEXT.md.
