## Overview
Run a 4D product playbook (Discover, Define, Design, Deliver) on a raw requirement and produce a spec file with user stories, Given/When/Then acceptance criteria, a test case table and a technical design. No code changes. Cheap session: read CONTEXT.md, write one file, open one small PR. Fill in before starting: repo, base branch, ticket id, the requirement text.

## Procedure
1. **Boot**: start from the snapshot, `git checkout -b devin/<ticket>-spec origin/<base_branch>`.
2. **Load context**: read `.github/copilot-context/CONTEXT.md` and, if present, `contracts.md` and `PROJECT.md`. Do not explore beyond that unless a story needs a specific screen or endpoint located.
3. **Discover**: write the problem statement, affected users and current flow, assumptions marked VALIDATED or OPEN, and at most 3 open questions with the default you will take.
4. **Define**: write up to 8 user stories with MUST / SHOULD / COULD priority, 2-5 Given/When/Then acceptance criteria each, relevant non-functional requirements, and an explicit out-of-scope list.
5. **Design**: UI components and states, API endpoints and shapes (mark `planned` in contracts.md), data and migrations, risks with mitigations. Max 25 lines.
6. **Deliver plan**: a test case table `ID | story | type | steps | expected` covering every criterion, a delivery order with one ticket per story sized for one PR, and the definition of done.
7. **Write**: save to `.github/copilot-context/specs/<date>-<ticket>.md`, under 200 lines.
8. **PR**: commit `<ticket>: spec`, push, open a PR into <base_branch> with the story list in the body.
9. **Stop**: post the PR link and the OPEN assumptions, end the session. Implementation happens later with the feature-loop or pr-per-task playbook, one story per session or per batch.

## Advice & Pointers
- Reuse names of existing components, endpoints and tables from CONTEXT.md; mark anything new as NEW.
- Every criterion must be measurable; replace "fast" or "works" with a number or an observable outcome.
- If the requirement is too vague for even one testable story, ask ONE question and stop.

## Forbidden actions
- Editing source, tests or config files.
- Running builds or test suites.
- Starting implementation in the same session.
