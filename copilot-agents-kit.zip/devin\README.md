# Devin setup - more PRs, fewer ACU

ACU is billed on compute time. The three leaks are: (1) every new session re-installs the project,
(2) sessions stay open waiting on CI / on you, (3) vague tasks cause re-reads and retries.
Everything below removes one of those leaks.

## 1. Do environment setup ONCE: machine snapshot

Devin > Settings > Repositories (or "Devin's Machine") > add the repo (or the zip, see section 4).
Fill the setup steps using your SETUP.md (produced by the Copilot `setup` agent, same file works here):

| Devin field | Put here |
|-------------|----------|
| Install dependencies | the exact install commands (nvm use, corepack, pnpm install, registry login via secret) |
| Maintain dependencies | `pnpm install` (runs when lockfile changes) |
| Lint | lint command |
| Tests | unit test command (keep it the fast one) |
| Run app | dev command + port |
| Secrets | registry token, proxy, NPM_TOKEN etc. as **Secrets**, never in commands |

Then click **Snapshot** (or "Save machine"). Every new session starts from the snapshot: no re-install, no proxy
fight, usually saves 0.5-2 ACU per session. Re-snapshot only when the lockfile or toolchain changes.

## 2. Give context once: Knowledge + CONTEXT.md

- Devin > Knowledge > add the entries from `devin/knowledge/*.md` (01-03 global rules, 04-06 per repo, 07 the 4D product playbook rules, 08 scoped context per task). Knowledge is injected into every session for free
  (no re-discovery). Keep each entry short and scoped to the repo/trigger.
- Commit `.github/copilot-context/CONTEXT.md` (from the Copilot kit) to the repo, or paste it as a Knowledge entry
  named "<repo> project context". Playbooks below tell Devin to read it instead of exploring.

## 3. Use playbooks instead of free-text prompts

Devin > Playbooks > New > paste each file in `devin/playbooks/`. Start a session by picking the playbook and filling
the blanks. Playbooks remove the back-and-forth that eats ACU and force one-PR-per-task.

| Playbook | Use |
|----------|-----|
| `STEP-BY-STEP.md` | full click-by-click guide: secrets, knowledge, playbooks, machines, daily loop |
| `product-4d.md` | requirement -> spec PR (stories, criteria, test cases, design); run before feature-loop |
| `pr-per-task.md` | the default: one small task -> branch -> PR -> stop |
| `batch-prs.md` | N independent small tasks in ONE session, one PR each (cheapest per PR) |
| `feature-loop.md` | criteria -> implement -> test -> iterate, same loop as the Copilot agent |
| `context-refresh.md` | update CONTEXT.md after big merges |
| `zip-onboard.md` | first-time setup from a zip when the repo is not accessible |

## 4. Repos Devin cannot access: zip workflow without re-uploading every time

1. Zip the repo **without** `node_modules`, `dist`, `.next`, `coverage` (`git archive -o repo.zip HEAD` is the cleanest).
2. New session with playbook `zip-onboard.md`, attach the zip. Devin unzips to `~/repos/<name>`, runs SETUP.md, and you
   **snapshot the machine** at the end. From now on every session starts with the code already there.
3. For updates, do not upload the whole zip again. Upload a patch: on your machine run
   `git diff <last-sync-commit> HEAD > sync.patch` and attach it; the playbook applies it with `git apply`.
   Record the synced commit in CONTEXT.md "Last synced commit".
4. Devin cannot push to a repo it cannot access. Have it produce `git format-patch base..HEAD -o out/` and
   download the patches (or a branch bundle: `git bundle create feature.bundle base..HEAD`), then push the PR from your machine:
   `git am out/*.patch` then `git push -u origin feature/x`.

## 5. Stop CI from running on every Devin push (no more manual pipeline stopping)

Use a branch naming rule instead of stopping pipelines by hand. Devin pushes to `devin/*` branches; CI ignores those
until a PR is opened or until you rename/merge into your feature branch.
- GitHub Actions: `devin/ci/github-actions-gate.yml` snippet.
- Tekton Triggers: `devin/ci/tekton-cel-filter.yaml` snippet (CEL filter on branch ref).
- Harness: in the trigger, set Branch condition `Does Not Start With` `devin/` (`devin/ci/harness-trigger-note.md`).
Then open the PR from `devin/<task>` into your feature branch (not main), which is what your team wants anyway.

## 6. Session hygiene (biggest ACU saver after snapshots)

- Use **Ask Devin / DeepWiki** (not a session) for questions, plans and "where is X" - it does not burn session ACU.
- One session = one playbook run. When the PR is up, say "done, sleep" or end the session. Idle sessions still cost.
- Do not let Devin wait for CI. Playbooks end at "PR opened"; you review CI results yourself or ask Devin Review.
- Turn on **Interactive Planning** in settings so Devin confirms the plan (cheap) before executing (expensive).
- Give the branch and base explicitly in every prompt; letting Devin guess the branch costs a fetch + exploration.
- Prefer `batch-prs.md` for 3-6 small tickets: one environment boot, N PRs.

## 7. About "hooks"

There are three different things people call hooks; pick the one you meant:
1. **Devin API webhook / automation** - an HTTP call that starts a session with a playbook (e.g. from Jira or a Slack
   command). See `devin/api-session.ps1`. Use it to launch `pr-per-task` runs without opening the UI.
2. **Git hooks** (`.git/hooks/pre-push`, `pre-commit`) - local scripts. Not visible to Devin unless committed via Husky.
   If you created one of these, it only runs on your machine.
3. **Repo setup "hooks"** in Devin's machine settings (install/lint/test commands) - these are section 1 above.
If you tell me which one you created (file name or where you clicked), I will wire it up precisely.
