## Overview
Implement several independent small tickets in ONE session, each on its own branch with its own PR into the named feature branch. Cheapest ACU per PR: the environment boots once and CONTEXT.md is read once. Fill in before starting: repo, base feature branch, and the list of tickets (id + one-line task each, max 6).

## Procedure
1. **Boot once**: start from the machine snapshot. Read `.github/copilot-context/CONTEXT.md` once; do not re-read it per ticket.
2. **For each ticket, branch fresh**: `git checkout -b devin/<ticket>-<slug> origin/<base_branch>` so every PR is independent of the others.
2b. **Scoped context**: take the story's Touch list from the spec if one exists, else derive a slice (files to change, callers, contracts, test files, verify commands for those packages, max 15 files) and post it; read and edit only that slice.
3. **Implement**: minimal diff, repo conventions, reuse existing pieces, no unrelated files.
4. **Test**: add or update tests, run typecheck, lint and unit tests for touched packages only.
5. **Commit and push**: message `<ticket>: <summary>`, push the branch.
6. **Open PR into <base_branch>**: title `<ticket>: <summary>`, body with summary, criteria table, commands run.
7. **Post the link and move on**: post the PR link in chat and start the next ticket immediately.
8. **Blocked ticket**: if a ticket needs missing info or hits unrelated failing tests, add it to a "Blocked" list with the reason and continue with the others.
9. **Finish**: post a table `ticket | PR link | status`, then the Blocked list.
10. **Stop**: do not wait for CI, end the session.

## Advice & Pointers
- Keep each diff under about 300 lines; if a ticket is bigger, do the first part, say what remains, and mark it partial.
- Never let one ticket's work leak into another branch; always branch from origin/<base_branch>, never from the previous ticket.
- Ask at most one clarifying question per ticket, then move on if unanswered.

## Forbidden actions
- More than 6 tickets per session.
- Pushing to main or the feature branch directly. Merging. Force-pushing.
- Reinstalling the environment or installing global tools.
- Weakening or deleting tests.
- Waiting for or polling CI.
