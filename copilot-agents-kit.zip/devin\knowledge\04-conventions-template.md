## Name
<repo> conventions   (one entry per repo, keep under 40 lines)

## Trigger (when Devin should use this)
Working in <repo> (folder `~/repos/<repo>` or the connected repository <org>/<repo>).

## Content
Repo location on the machine: `~/repos/<repo>`
Context file: `~/repos/<repo>/.github/copilot-context/CONTEXT.md`  (read it first; this entry is the fallback)
Shared files for the project: `~/repos/shared/PROJECT.md`, `~/repos/shared/contracts.md`

Paste the "Conventions", "Commands" and "Key reusable pieces" sections of CONTEXT.md below.

### Conventions
- 

### Commands
| Task | Command |
|------|---------|
| install | |
| lint | |
| typecheck | |
| test | |
| dev | |

### Key reusable pieces
- 

## Forbidden
- Creating a new component, service or utility when one listed above fits.
- Using a state or styling library not listed above.
