---
description: Record or replay IDE configuration (IntelliJ project and user settings, Maven/Gradle user config, VS Code) without touching source code
agent: setup
---
IDE sync, mode ${input:mode:baseline, diff, record or replay}.
- baseline: snapshot all IDE/project/user config files right after clone (before manual setup) into `ide/baseline/` with hashes.
- diff: compare current config against the baseline, write only the changed settings as numbered steps and local overrides into
  SETUP.md, mask secrets, refresh the baseline. Falls back to git diff if no baseline exists.
- record: capture IntelliJ .idea project files, user-level options (JDKs, proxy host/port, keymap, plugins), Maven/Gradle user config
  (names and URLs only), VS Code settings and extensions, into `.github/copilot-context/ide/` and the IDE section of SETUP.md.
  Ask me to export IntelliJ settings to `ide/intellij/settings.zip` if it is missing.
- replay: restore `.idea/` files, print the exact `idea64.exe installPlugins` command, tell me how to import settings.zip and add the JDK,
  write Maven/Gradle user config with placeholder credentials, install VS Code extensions, then verify the project opens without SDK or
  dependency errors.
Never copy workspace.xml or any file with passwords or tokens.
