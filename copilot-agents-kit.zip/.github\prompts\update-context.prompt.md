---
description: Create or refresh .github/copilot-context/CONTEXT.md for the current branch
agent: context-builder
---
Update the project context for the current branch.
- If CONTEXT.md exists, diff the repo against it and change only what is stale.
- Always refresh: "Last updated", "Recent changes", and the branch file.
- Report what you changed in 5 lines.
