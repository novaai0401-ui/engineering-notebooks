# Harness: stop pipelines from firing on devin/* pushes

Pipeline > Triggers > your Git push trigger > Conditions tab:
- Branch Name: operator `Does Not Start With`, value `devin/`

Keep the Pull Request trigger as-is (target branch `feature/*` or whatever your team uses) so PRs still get validated.

If you prefer YAML, in the trigger spec:
```yaml
source:
  type: Webhook
  spec:
    type: Github
    spec:
      type: Push
      spec:
        payloadConditions:
          - key: targetBranch
            operator: DoesNotStartWith
            value: devin/
```
Result: you never have to stop a pipeline by hand while Devin iterates; CI runs once, on the PR.
