## Name
<repo> project context   (one entry per repo; mirrors CONTEXT.md, used when the file is not on the machine)

## Trigger (when Devin should use this)
Any task in <repo> when `~/repos/<repo>/.github/copilot-context/CONTEXT.md` is missing or older than this entry.

## Content
Repo: <org>/<repo> | Base branch: <main> | Machine folder: `~/repos/<repo>` | Last updated: <date>

### Stack
| Area | Tech / version |
|------|----------------|
| UI | |
| State | |
| Backend | |
| Build | |
| Tests | |
| CI/CD | |

### Folder map (top 2 levels)
- `src/...` - purpose

### Conventions
#### UI
- 
#### Backend
- 
#### Testing
- 

### Commands
| Task | Command |
|------|---------|
| lint | |
| typecheck | |
| test | |
| dev | |
| build | |

### Key reusable pieces (reuse before creating)
- `path` - what it is

### Integration points
- env vars (names only): 
- external services: 
- micro-frontend / module federation: 
- pipelines: 

### Gotchas
- 

### Recent changes (latest 15)
- YYYY-MM-DD (branch): summary - files

## Forbidden
- Storing secret values, tokens or credentialed URLs.
- Letting this entry exceed about 250 lines; trim Recent changes first.
