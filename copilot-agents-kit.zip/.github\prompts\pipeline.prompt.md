---
description: Change or add Tekton / Harness / Kubernetes / Helm / Docker config and validate it locally
agent: devops
---
DevOps task: ${input:task:Describe the pipeline / manifest / Dockerfile change}

Constraints:
- Read CONTEXT.md first; scan only pipeline/manifest folders if DevOps info is missing.
- One concern per change, no reformatting, no secrets, no real deploys or pipeline triggers.
- Validate locally with every tool available (yaml lint, kubectl/oc dry-run, helm lint/template, hadolint) and report results.
