## Name
Scoped context per task (load only the slice you change)

## Trigger (when Devin should use this)
Start of every implementation, fix or review task, after CONTEXT.md has been read.

## Content
Build a fresh, task-sized context before touching code, and write it at the top of the run file (`.github/copilot-context/runs/<date>-<ticket>.md`) under "## Scoped context":
1. Source of the slice: the story's **Touch list** from the spec if one exists; otherwise derive it from the ticket text by grepping CONTEXT.md "Key reusable pieces" and the folder map for the named screen, component, endpoint or table.
2. List: files to change, files to read for reference (callers found with grep or usages), the endpoint or type contracts involved, the test files that cover them, and the exact verify commands for just those packages.
3. Cap: at most 15 files in the slice. If more are needed, the task is too big; split it and say so.
4. Read only the files in the slice. Do not open folders, do not re-read CONTEXT.md, do not search the whole repo again. If something outside the slice turns out to be needed, add it to the list with a one-line reason before reading it.
5. Changes stay inside the slice. Anything outside becomes a note in the PR body, not an edit.
6. Verification runs only the commands listed in the slice (typecheck, lint, tests for those packages).
7. On finish, the slice plus the diff summary becomes the "Recent changes" line in CONTEXT.md, so the next task can reuse it.

## Forbidden
- Broad repo exploration or full test suites when a slice exists.
- Editing files outside the slice without listing them first.
- Re-deriving the slice for a story that already has a Touch list in the spec.
