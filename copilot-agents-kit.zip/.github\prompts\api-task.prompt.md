---
description: Implement a backend change using the saved context
agent: api-dev
---
Implement this backend change: ${input:task:Describe the API/backend change}

Constraints:
- Read CONTEXT.md first; do not re-scan the repo.
- Keep API contracts backward compatible; flag any breaking change.
- Validate inputs, add/update tests, run lint + typecheck + tests, then log the change in CONTEXT.md.
