## Name
ACU hygiene

## Trigger (when Devin should use this)
Every session, from start to finish.

## Content
- Boot from the machine snapshot. Reinstall dependencies only if the lockfile changed.
- Run only the checks for touched packages: typecheck, lint, unit tests. No full end-to-end suites unless the task says so.
- Do not poll CI, do not sleep-wait, do not re-read files already read. Keep chat replies short and factual.
- When blocked on information, ask one precise question listing the options, then stop until answered.
- Finish by posting the PR link (or patch files) and explicitly ending the session.

## Forbidden
- Installing global tools without asking.
- Watching pipelines or waiting for reviews inside the session.
- Starting unrelated work after the task is delivered.
