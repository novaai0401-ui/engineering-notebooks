# Devin: step-by-step consumption guide

Everything happens in the Devin web app. Files in this folder are text you paste into it.

## Part 0: produce the two source files on your laptop (once per repo)
1. Open the repo in VS Code with the Copilot kit installed.
2. Run `/record-setup`  -> writes `.github/copilot-context/SETUP.md`.
3. Run `/update-context` -> writes `.github/copilot-context/CONTEXT.md`.
4. Commit both if you can. If you cannot commit, keep them in the repo folder anyway; they will travel inside the zip.

## Part 1: Secrets (once)
1. Devin app, left sidebar, Settings, Secrets, Add secret.
2. Add every name from the SETUP.md "Environment variables" table and the registry token, e.g. NPM_TOKEN, HTTPS_PROXY.
3. Never paste values anywhere else. Playbooks and Knowledge refer to names only.

## Part 2: Knowledge (once, then one entry per repo)
1. Sidebar, Knowledge, Add knowledge.
2. For each file in `devin/knowledge/`: title = the "## Name" line, trigger field = the "## Trigger" text, body = the "## Content" and "## Forbidden" sections.
3. Entries 01-03 are global. Scope them to all repos.
4. Entries 04, 05, 06 are per repo. Copy them once per repo, replace `<repo>`, and fill the body from that repo's CONTEXT.md and SETUP.md. Scope each to that repo.
5. Save. Knowledge is injected into every session automatically and costs no ACU.

## Part 3: Playbooks (once)
1. Sidebar, Playbooks, New playbook.
2. Select all in the editor, paste one file from `devin/playbooks/`, name it after the file, Save.
3. Repeat for: pr-per-task, batch-prs, feature-loop, context-refresh, zip-onboard, multi-repo-workspace.

## Part 4A: machine for a CONNECTED repo (once per repo)
1. Settings, Repositories, Add repository, pick the repo.
2. Fill the setup fields from SETUP.md:
   - Install dependencies: the install commands, using `$NPM_TOKEN` etc. from Secrets
   - Maintain dependencies: `pnpm install --frozen-lockfile`
   - Lint, Tests, Run app: the commands from the "Run and check" table
3. Click Test next to each field until all pass. Fix SETUP.md if a command was wrong.
4. Click Snapshot (or Save). Done; every session starts from here.

## Part 4B: machine for a NON-CONNECTED repo (once per project)
1. On your laptop, in the repo: `git archive -o repo.zip HEAD` and `git rev-parse --short HEAD`.
   The zip already contains `.github/copilot-context/SETUP.md` and `CONTEXT.md` from Part 0.
2. New session, choose playbook zip-onboard, drag the zip into the prompt, type the project name and the SHA, send.
3. Devin asks for secret names it needs; add them in Settings, Secrets, reply "done".
4. Repeat step 2 inside the same session for each additional repo of the project (frontend, backend).
5. When Devin says "ready to snapshot": Settings, Repositories (or Machines), open this machine, Snapshot.

## Part 5: daily task (every time)
1. Questions and planning: use Ask Devin / DeepWiki tab. No session, no ACU.
2. New session, pick a playbook:
   - one ticket: pr-per-task (connected) or multi-repo-workspace (zipped)
   - several small tickets: batch-prs
   - whole feature with acceptance criteria loop: feature-loop
3. Fill the blanks in the prompt: repo or folder, base feature branch, ticket, task, and for zipped repos the sync method (`fetch`, `patch` with sync.patch attached, or `none`).
4. Send. Interactive Planning shows a plan; approve it.
5. Connected repo: Devin opens the PR into your feature branch, posts the link. Click End session.
   Zipped repo: Devin attaches patch files and the PR text. Download, then on your laptop:
   `git checkout -b devin/<ticket> <base>` , `git am out/*.patch` , `git push -u origin devin/<ticket>` , open the PR. Click End session.
6. CI runs once on the PR because `devin/*` pushes are filtered (see `devin/ci/`).

## Part 6: keeping memory fresh
- After big merges: session with context-refresh (connected) or `/update-context` in VS Code then a new zip/patch (zipped).
- Paste the updated Conventions and Commands into the "<repo> project context" Knowledge entry.
- Re-snapshot only when a lockfile or tool version changes.
- When a setup error bites you, add it to "Known errors" in both SETUP.md and the "<repo> setup" Knowledge entry.

## What counts toward the Devin PR score
Only PRs Devin opens itself through a connected repo. Patches you push do not count. Use connected repos for the work that is measured.
