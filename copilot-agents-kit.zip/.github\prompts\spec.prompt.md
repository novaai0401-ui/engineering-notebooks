---
description: 4D product playbook - requirement to user stories, acceptance criteria, test cases and design (no code)
agent: product
---
Run the 4D playbook on this requirement: ${input:requirement:Paste the ticket, requirement or idea}

Produce the spec file with Discover, Define, Design and Deliver sections, every acceptance criterion mapped to a test case,
and stories sized for one PR each. Then offer the feature-loop handoff.
