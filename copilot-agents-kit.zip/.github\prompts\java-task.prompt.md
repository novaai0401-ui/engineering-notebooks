---
description: Implement a Java backend change using the saved context
agent: java-dev
---
Implement this Java change: ${input:task:Describe the backend change}

Constraints:
- Read CONTEXT.md first; do not re-scan the repo.
- Keep REST contracts backward compatible; add a migration for any entity change.
- Add/update tests, run the build and tests from CONTEXT.md, then log the change in CONTEXT.md.
