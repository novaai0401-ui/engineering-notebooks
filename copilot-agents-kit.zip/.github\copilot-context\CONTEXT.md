# Project context - <repo name>
Last updated: (not yet generated) | Branch when updated: - | Base branch: main

> This file is generated and maintained by the `@context-builder` agent.
> Run `/update-context` in Copilot Chat to fill it in. Agents read this file
> instead of re-scanning the repository on every chat.

## Stack
| Area | Tech / version |
|------|----------------|
| | |

## Folder map
- 

## Conventions
### UI
- 
### Backend
- 
### Testing
- 

## Commands
| Task | Command |
|------|---------|
| install | |
| dev | |
| build | |
| lint | |
| typecheck | |
| test | |

## Key reusable pieces (reuse before creating)
- 

## Integration points
- env vars (names only): 
- external services: 
- micro-frontend / module federation: 

## Gotchas
- 

## Recent changes
- 
