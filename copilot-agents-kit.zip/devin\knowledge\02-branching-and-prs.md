## Name
Branching and PR rules

## Trigger (when Devin should use this)
Creating a branch, committing, pushing, or opening a pull request.

## Content
- Branch from the feature branch named in the prompt, never from main unless told. Branch name: `devin/<ticket>-<slug>`.
- One task = one branch = one PR into the feature branch. Keep diffs under about 300 lines; split larger work and say so.
- Commit message: `<ticket>: <summary>`.
- PR body: summary, acceptance criteria PASS/FAIL table, commands run with results, screenshots for UI changes.
- Append one line under "## Recent changes" in CONTEXT.md and include it in the same PR.
- After opening the PR, post the link and stop; do not wait for CI.
- No push access: deliver `git format-patch <base>..HEAD -o out/` files plus the PR title and description in chat.

## Forbidden
- Merging. Pushing to main or directly to the feature branch. Force-pushing.
- Opening more than one PR per task.
