## Overview
Deliver a full feature end to end: write acceptance criteria, design, implement backend and/or UI, test, verify each criterion, and iterate until all pass or the retry budget is spent. Ends with one PR into the named feature branch. Fill in before starting: repo, base feature branch, ticket id, the goal in one sentence (the motive, not the mechanics), and any known constraints.

## Procedure
1. **Boot and branch**: start from the snapshot, `git checkout -b devin/<ticket>-<slug> origin/<base_branch>`.
2. **Load context**: read `.github/copilot-context/CONTEXT.md`, and `contracts.md` / `PROJECT.md` if present in `.github/copilot-context/` or `~/repos/shared/`.
3. **Write the run file**: create `.github/copilot-context/runs/<date>-<ticket>.md` with Goal, 3-8 checkable acceptance criteria, Out of scope, and a Design section (files, layers, reused pieces, risks, max 15 lines). Post it in chat and continue.
3b. **Scoped context**: write a "## Scoped context" section in the run file from the spec's Touch list or a derived slice (max 15 files); read and edit only that slice; add any extra file with a one-line reason first.
4. **Implement in order**: backend contract first if any, then UI, then tests for every criterion.
5. **Verify**: run typecheck, lint and tests for touched packages; mark each criterion PASS or FAIL in the run file with evidence (test name, output line, or file:line).
6. **Iterate on FAIL**: read the failing output, find the root cause, fix, re-run step 5. Log each iteration in the run file as `#n - what failed - what changed`.
7. **Stop conditions**: max 5 iterations; stop early if the same criterion fails 3 times with different fixes and report it.
8. **Update shared files**: if an API changed, update `contracts.md`; append a line under "## Recent changes" in CONTEXT.md.
9. **Commit, push, open PR into <base_branch>**: include the run file; PR body has the criteria table, iterations used, commands run, open items.
10. **Stop**: post the PR link and end the session.

## Advice & Pointers
- A criterion that cannot be tested must be proven by a command whose output you quote.
- If the goal is too vague to write checkable criteria, ask ONE focused question and wait.
- Prefer small, reviewable commits per phase (contract, UI, tests).

## Forbidden actions
- Weakening, skipping or deleting tests to reach PASS.
- Refactoring outside the Out of scope line.
- Pushing to main or the feature branch directly, merging, force-pushing.
- Reinstalling the environment. Waiting for CI.
