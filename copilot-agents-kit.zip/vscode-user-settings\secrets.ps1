# Encrypted local secret vault for the Copilot kit. ZERO dependencies: uses Windows DPAPI via built-in PowerShell 5.1.
# Values are encrypted with your Windows user + machine key and stored in %LOCALAPPDATA%\copilot-kit\vault.json.
# Only you, logged in on this machine, can decrypt them. Nothing is downloaded or installed.
#
# Save a value: .\secrets.ps1 set NPM_TOKEN            (hidden prompt)
# Read a value: .\secrets.ps1 get NPM_TOKEN
# List names:   .\secrets.ps1 list
# Load all into env vars for the current shell:  .\secrets.ps1 env
# Delete:       .\secrets.ps1 delete NPM_TOKEN
# New machine:  .\secrets.ps1 export C:\path\vault.export   (encrypted with a password you choose)
#               .\secrets.ps1 import C:\path\vault.export   (then delete the file)
param(
  [Parameter(Mandatory)] [ValidateSet('set','get','list','env','delete','export','import','set-from-stdin')] [string]$Action,
  [string]$Name,
  [string]$Path,
  [Parameter(ValueFromPipeline=$true)] [string]$Value
)
$dir  = Join-Path $env:LOCALAPPDATA 'copilot-kit'
$file = Join-Path $dir 'vault.json'
if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }

function Load-Vault {
  if (Test-Path $file) { $o = Get-Content $file -Raw | ConvertFrom-Json; $h=@{}; foreach ($p in $o.PSObject.Properties) { $h[$p.Name]=$p.Value }; return $h }
  return @{}
}
function Save-Vault($h) { $h | ConvertTo-Json | Set-Content -Path $file -Encoding utf8 }
function Protect($plain)  { ConvertTo-SecureString -String $plain -AsPlainText -Force | ConvertFrom-SecureString }   # DPAPI
function Unprotect($enc)  { [System.Net.NetworkCredential]::new('', ($enc | ConvertTo-SecureString)).Password }
function KeyFrom($securePw) { [System.Text.Encoding]::UTF8.GetBytes(([System.Net.NetworkCredential]::new('', $securePw).Password).PadRight(32).Substring(0,32)) }

switch ($Action) {
  'set' {
    if (-not $Name) { throw "Name required" }
    $sec = Read-Host -Prompt "Value for $Name" -AsSecureString
    $v = Load-Vault; $v[$Name] = Protect ([System.Net.NetworkCredential]::new('', $sec).Password); Save-Vault $v
    Write-Output "Stored $Name"
  }
  'set-from-stdin' {
    # for the agent: echo <value> | secrets.ps1 set-from-stdin NAME   (value never appears in chat)
    if (-not $Name) { throw "Name required" }
    $plain = if ($Value) { $Value } else { [Console]::In.ReadLine() }
    $plain = $plain.TrimEnd("`r","`n")
    if (-not $plain) { throw "No value received on stdin" }
    $v = Load-Vault; $v[$Name] = Protect $plain; Save-Vault $v
    Write-Output "Stored $Name"
  }
  'get' {
    if (-not $Name) { throw "Name required" }
    $v = Load-Vault; if (-not $v.ContainsKey($Name)) { throw "Missing secret: $Name" }
    Unprotect $v[$Name]
  }
  'list'   { (Load-Vault).Keys | Sort-Object }
  'env' {
    $v = Load-Vault
    foreach ($k in $v.Keys) { Set-Item -Path "Env:$k" -Value (Unprotect $v[$k]) }
    Write-Output "Loaded $($v.Count) secrets into this shell's environment."
  }
  'delete' { $v = Load-Vault; $v.Remove($Name) | Out-Null; Save-Vault $v; Write-Output "Deleted $Name" }
  'export' {
    if (-not $Path) { throw "Path required" }
    $pw = Read-Host -Prompt "Export password" -AsSecureString
    $v = Load-Vault; $plain=@{}; foreach ($k in $v.Keys) { $plain[$k] = Unprotect $v[$k] }
    $json = $plain | ConvertTo-Json
    ConvertTo-SecureString -String $json -AsPlainText -Force | ConvertFrom-SecureString -SecureKey (KeyFrom $pw) | Set-Content -Path $Path -Encoding utf8
    Write-Output "Exported $($plain.Count) secrets (password-encrypted) to $Path. Delete it after importing."
  }
  'import' {
    if (-not $Path) { throw "Path required" }
    $pw = Read-Host -Prompt "Export password" -AsSecureString
    $json = [System.Net.NetworkCredential]::new('', (Get-Content -Path $Path -Raw | ConvertTo-SecureString -SecureKey (KeyFrom $pw))).Password
    $o = $json | ConvertFrom-Json; $v = Load-Vault
    foreach ($p in $o.PSObject.Properties) { $v[$p.Name] = Protect $p.Value }
    Save-Vault $v
    Write-Output "Imported $($o.PSObject.Properties.Count) secrets."
  }
}
