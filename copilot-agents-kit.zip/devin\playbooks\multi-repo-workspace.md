## Overview
Work on one task in a repo that lives on the snapshot under `~/repos/<name>` (cloned with a read-only token or unzipped), alongside other repos of the same project and a shared contracts folder. Fill in before starting: repo folder, sync method (fetch | patch | none), base branch, ticket id, task.

## Procedure
1. **Boot**: start from the snapshot, `cd ~/repos/<repo>`.
2. **Sync**: fetch: `git fetch origin <base_branch> && git checkout -B work origin/<base_branch>`; patch: `git apply --3way sync.patch`, commit `sync <sha>`, tag `sync-<sha>`; none: continue on the current checkout.
3. **Load context**: read `.github/copilot-context/CONTEXT.md`, then `~/repos/shared/PROJECT.md` and `~/repos/shared/contracts.md`.
4. **Branch**: `git checkout -b devin/<ticket>-<slug>`.
5. **Implement and test**: follow the pr-per-task rules (minimal diff, conventions, tests, typecheck/lint/tests for touched packages).
6. **Contracts**: if an endpoint or shared type changed, update `~/repos/shared/contracts.md` and say so.
7. **Deliver with write access** (token limited to `devin/*`): push and open a PR into <base_branch>.
8. **Deliver without write access**: `git format-patch <base_branch>..HEAD -o out/` (or `sync-<sha>..HEAD`), attach the files, paste the PR title and description in chat.
9. **Log**: append a line under "## Recent changes" in CONTEXT.md.
10. **Stop**: post the PR link or patch list and end the session.

## Advice & Pointers
- Never guess which repo a task belongs to; the folder is given in the prompt or listed in PROJECT.md.
- Cross-repo tasks: do the backend contract first, update contracts.md, then the UI, each as a separate PR or patch set.
- No re-snapshot is needed after a task; only after a lockfile change.

## Forbidden actions
- Touching a repo folder other than the one named.
- Pushing to main or the feature branch directly, merging, force-pushing.
- Reinstalling dependencies without a lockfile change.
- Waiting for CI. Printing secret values.
