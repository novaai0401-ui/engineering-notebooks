## Name
4D product playbook rules (Discover, Define, Design, Deliver)

## Trigger (when Devin should use this)
Any request that is a requirement, idea, epic or ticket without acceptance criteria; any session using the product-4d playbook; any feature-loop session that has no spec yet.

## Content
Spec location: `.github/copilot-context/specs/<date>-<ticket>.md`. If a spec exists for the ticket, read it and skip to delivery.

Discover: one-sentence problem statement; affected users and their current flow (from CONTEXT.md); assumptions marked VALIDATED or OPEN; max 3 open questions, each with the default you will take.
Define: up to 8 user stories `As a <role> I want <capability> so that <outcome>` with MUST / SHOULD / COULD; 2-5 Given/When/Then criteria per story, each measurable; non-functional needs only where relevant; explicit out-of-scope list.
Design: components and states, endpoints and shapes (mark `planned` in contracts.md), data and migrations, risks with mitigations; max 25 lines; reuse names from CONTEXT.md and mark anything new as NEW.
Deliver: test case table `ID | story | type | steps | expected` covering every criterion; one ticket per story sized for one PR; a **Touch list** per story (files, components, endpoints, tables it will change) so delivery sessions load only that slice; definition of done.

Spec under 200 lines. Spec PR is separate from implementation PRs.

## Forbidden
- Writing code, tests or config in a spec session.
- Vague criteria such as "works", "fast", "user friendly".
- Starting implementation before the spec PR exists.
