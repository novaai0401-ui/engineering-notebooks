## Overview
Set up a repository that Devin cannot access, from an attached zip, so the machine can be snapshotted with the code and dependencies ready. Later sessions update it from a patch instead of a new zip. Fill in before starting: project name, the commit SHA the zip was made from, and attach the zip (no node_modules) plus SETUP.md and CONTEXT.md if available.

## Procedure
1. **Unzip**: `mkdir -p ~/repos/<project> && unzip -q <zip> -d ~/repos/<project>`; strip the top-level folder if the zip has one.
2. **Init git if missing**: `git init && git add -A && git commit -m "sync <sha>" && git tag sync-<sha>`.
3. **Run SETUP.md**: install tools and dependencies, ask for each env var NAME to be provided as a Secret, then build, test and start the dev server. Record every error and the fix that worked under "Known errors" in SETUP.md.
4. **Build CONTEXT.md if missing**: follow the context-refresh rules (manifests, folder map, one sample per category, max 250 lines). Add the line `Last synced commit: <sha>`.
5. **Shared folder**: ensure `~/repos/shared/PROJECT.md` and `contracts.md` exist; create from the templates if not.
6. **Report**: say "ready to snapshot" with the folder list and any unresolved setup issues, then stop so the machine can be snapshotted.
7. **Later sessions, patch update**: apply the attached `sync.patch` with `git apply --3way sync.patch`, commit `sync <new sha>`, tag `sync-<new sha>`, update "Last synced commit" in CONTEXT.md, then continue with the task playbook named in the prompt.
8. **Delivering work without push access**: `git format-patch sync-<sha>..HEAD -o out/` (or `git bundle create out/feature.bundle sync-<sha>..HEAD`), attach the files, and paste the PR title and description in chat.

## Advice & Pointers
- Zips should be created with `git archive -o repo.zip HEAD` so they contain no build output.
- Do not re-upload a full zip for updates; a patch is seconds, a zip is minutes of ACU.
- Keep one machine for all repos of the same project so one snapshot covers frontend and backend.

## Forbidden actions
- Printing or storing secret values.
- Installing global tools that need admin rights without asking.
- Modifying source files during onboarding; only SETUP.md, CONTEXT.md and local tool config.
